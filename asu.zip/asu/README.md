### Features
| Feature |Yes|
| ------------- | ------------- |
| Play Music|✅|
| Play Video |✅|
| Sticker |✅|
| Upload story insta |✅|
| Nhentai |✅|
| Ytmp4 |✅|
| Ytmp3 |✅|
| Facebook download |✅|
| Respontag |✅|
### install
```
$ git clone https://github.com/Kikii-XyZ/selfbot-wa.git
$ cd selfbot-wa
$ npm install
$ node .
```
• FFMPEG: [Download Here](https://drive.google.com/file/d/1SugE8vjfOyyW3VTRqsxlW_GJh6EKQ19X/view?usp=drivesdk)

## 📢 
> [Kenalan:v](https://wa.me/628137756694)
